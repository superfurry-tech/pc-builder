package montaje.ejecutable;

import montaje.caja.Caja;
import montaje.caja.FuenteAlimentacion;
import montaje.caja.Pieza;
import montaje.caja.Refrigeracion;
import montaje.caja.placabase.*;
import montaje.enums.TipoSize;
import montaje.enums.TipoMemoriaDDR;
import montaje.enums.TipoPlaca;
import montaje.ordenador.Ordenador;

import java.util.ArrayList;

public class Main {
  static void main(String[] args) {
    MemoriaRamDdr ddr4_1 = new MemoriaRamDdr("DDR4_1", "FAB.PRIMEROS", 100,10, TipoMemoriaDDR.DDR4);


  }
}
